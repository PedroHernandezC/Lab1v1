#include "SortedVectorDict.hpp"

//Pre: "data" exist
//Post: If the key exist then the index of that key will have been returned otherwise the size of "data" will have been returned
std::size_t SortedVectorDict::lookup_idx(int key) const {
    int lowerBound = 0;
    int higherBound = data.size() - 1;

    while (lowerBound <= higherBound) {
        int middleIndex = (lowerBound + higherBound) / 2;
        if (data[middleIndex] == key) {
            return middleIndex;
        } else if (key < data[middleIndex]) {
            higherBound = middleIndex - 1;
        } else {
            lowerBound = middleIndex + 1;
        }
    }

    return data.size();
}

//Pre: "data" exist and key is correctly assigned
//Post: the key will have been added and the vector resorted in ascending order
void SortedVectorDict::insert(int key) {
    data.push_back(key);
    std::sort(data.begin(), data.end());
}

//Pre: None
//Post: If the key was found true will have been retured otherwise false
bool SortedVectorDict::lookup(int key) const {
    auto idx = lookup_idx(key);
    return idx != data.size();
}

//Pre: "data" exist
//Post: An element with the matching value will have been removed from the vector if it exsited
void SortedVectorDict::remove(int key) {
    auto idx = lookup_idx(key);
    if(idx != data.size()) {
        data[idx] = data.back();
        data.pop_back();
    }
}