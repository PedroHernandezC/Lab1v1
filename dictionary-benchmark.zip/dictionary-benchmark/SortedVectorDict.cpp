#include "SortedVectorDict.hpp"

std::size_t SortedVectorDict::lookup_idx(int key) const {

    for (auto i = 0; i < data.size(); i++) {
        if (data[i] == key)
            return i;
    }
    return data.size();

}

void SortedVectorDict::sorter() {
    std::sort(data.begin(), data.end());
}

void SortedVectorDict::insert(int key) {
    data.push_back(key);
    SortedVectorDict::sorter();
}

bool SortedVectorDict::lookup(int key) const {
    auto idx = lookup_idx(key);
    return idx != data.size();
}
void SortedVectorDict::remove(int key) {
    auto idx = lookup_idx(key);
    if(idx != data.size()) {
        data[idx] = data.back();
        data.pop_back();
    }
}