#pragma once
#include<vector>
#include<algorithm>

#include "Dictionary.hpp"
class SortedVectorDict : public Dictionary {
    public:
        void insert(int) override;
        [[nodiscard]] bool lookup(int) const override;
        void remove(int) override;
    private:
        std::vector<int> data;

        void sorter();
        [[nodiscard]] std::size_t lookup_idx(int) const;
};