#include "SortedLinkedListDict.hpp"
//Pre: A valid integer passed to the function
//Post: The vector "data" will have had a node with the past value inserted into it in ascending order
void SortedLinkedListDict::insert(int key) {
    const auto TEMP = new SortedLinkedListDict::Node();
    TEMP->data = key;

    auto current = SortedLinkedListDict::head;

    if (SortedLinkedListDict::head == nullptr || SortedLinkedListDict::head->data >= key) {
        TEMP->next = SortedLinkedListDict::head;
        SortedLinkedListDict::head = TEMP;
    } else {
        while (current->next != nullptr && current->next->data < key) {
            current = current->next;
        }

        TEMP->next = current->next;
        current->next = TEMP;
    }
}

//Pre: "data" is existing
//Post: If the passed value was found in "data" then true will have been returned
bool SortedLinkedListDict::lookup(int key) const {
    bool found = false;
    auto looker = SortedLinkedListDict::head;

    while (!found && looker != nullptr){
        if (looker->data == key){
            found = true;
        }

        looker = looker->next;
    }

    return found;
}

//Pre: "data" exist
//Post: If the past key is in "data" then the key will have been removed
void SortedLinkedListDict::remove(int key) {
    auto current = SortedLinkedListDict::head;
    auto last = current;

    if (SortedLinkedListDict::lookup(key)){
        // first case has the key pointed to by head
        if (current->data == key){
            // if there are more nodes then move head forward else move to null
            if (SortedLinkedListDict::head->next != nullptr){
                SortedLinkedListDict::head = SortedLinkedListDict::head->next;
            } else {
                SortedLinkedListDict::head = nullptr;
            }
            delete current;
        } else {
            current = current->next;
            do {
                if (current->data == key){
                    last->next = current->next;
                    delete current;
                    current = nullptr;
                }
                else {
                    last = current;
                    current = current->next;
                }
            } while( current != nullptr && current->next != nullptr);
        }
    }
}