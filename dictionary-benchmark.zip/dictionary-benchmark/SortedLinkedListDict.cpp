#include "SortedLinkedListDict.hpp"
void SortedLinkedListDict::insert(int key) {}
bool SortedLinkedListDict::lookup(int key) const { return false; }
void SortedLinkedListDict::remove(int key) {}