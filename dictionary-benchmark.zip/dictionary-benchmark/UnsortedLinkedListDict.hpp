#pragma once
#include "Dictionary.hpp"
#include <iostream>

class UnsortedLinkedListDict : public Dictionary {
public:
    void insert(int key) override;
    [[nodiscard]] bool lookup(int key) const override;
    void remove(int key) override;

private:
    struct Node {
        int data;
        Node* next = nullptr;
    };
    Node* head = nullptr;
};