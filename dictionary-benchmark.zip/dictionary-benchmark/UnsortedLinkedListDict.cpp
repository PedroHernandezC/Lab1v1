#include "UnsortedLinkedListDict.hpp"
void UnsortedLinkedListDict::insert(int key) {
    auto temp = new UnsortedLinkedListDict::Node();
    temp->data = key;
    temp->next = nullptr;

    if (UnsortedLinkedListDict::head == nullptr){
        UnsortedLinkedListDict::head = temp;
        UnsortedLinkedListDict::tail = temp;
    } else {
        UnsortedLinkedListDict::tail->next = temp;
        UnsortedLinkedListDict::tail = temp;
    }
}
bool UnsortedLinkedListDict::lookup(int key) const {
    bool found = false;
    auto looker = UnsortedLinkedListDict::head;

    if (looker->data == key){
        found = true;
    }

    while (!found && looker->next != nullptr){
        if (looker->data == key){
            found = true;
        }

        looker = looker->next;
    }

    return found;
}
void UnsortedLinkedListDict::remove(int key) {
    auto current = UnsortedLinkedListDict::head;
    auto last = UnsortedLinkedListDict::head;

    if (UnsortedLinkedListDict::lookup(key)){
        if (UnsortedLinkedListDict::head->data == key){
            if (UnsortedLinkedListDict::head->next != nullptr){
                UnsortedLinkedListDict::head = UnsortedLinkedListDict::head->next;
                delete current;
            } else {
                UnsortedLinkedListDict::head = nullptr;
                UnsortedLinkedListDict::tail = nullptr;
            }

        } else {
            last = current;
            current = current->next;
            do {
                if (current->data == key){
                    last->next = current->next;
                    delete current;
                    current = nullptr;
                }
            } while( current != nullptr && current->next != nullptr);
        }
    }
}