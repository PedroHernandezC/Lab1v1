#include "UnsortedLinkedListDict.hpp"

//Pre: head pointer and Node class exist
//Post:A node with key data will have been added to the start of the linked list
void UnsortedLinkedListDict::insert(int key) {
    const auto TEMP = new UnsortedLinkedListDict::Node();
    TEMP->data = key;

    if (UnsortedLinkedListDict::head == nullptr){
        TEMP->next = nullptr;
        UnsortedLinkedListDict::head = TEMP;
    } else {
        TEMP->next = UnsortedLinkedListDict::head;
        UnsortedLinkedListDict::head = TEMP;
    }
}

//Pre: Link list exist with head node.
//Post: if the key was found in the list then true will have been returned otherwise false
bool UnsortedLinkedListDict::lookup(int key) const {
    bool found = false;
    auto looker = UnsortedLinkedListDict::head;

    while (!found && looker != nullptr){
        if (looker->data == key){
            found = true;
        }

        looker = looker->next;
    }

    return found;
}

//Pre: linked list exist.
//Post: the node with matching value will have been removed and surrounding nodes relinked
void UnsortedLinkedListDict::remove(int key) {
    auto current = UnsortedLinkedListDict::head;
    auto last = current;

    if (UnsortedLinkedListDict::lookup(key)){
        // first case has the key pointed to by head
        if (current->data == key){
            // if there are more nodes then move head forward else move to null
            if (UnsortedLinkedListDict::head->next != nullptr){
                UnsortedLinkedListDict::head = UnsortedLinkedListDict::head->next;
            } else {
                UnsortedLinkedListDict::head = nullptr;
            }
            delete current;
        } else {
            current = current->next;
            do {
                if (current->data == key){
                    last->next = current->next;
                    delete current;
                    current = nullptr;
                }
                else {
                    last = current;
                    current = current->next;
                }
            } while( current != nullptr && current->next != nullptr);
        }
    }
}