# Dictionary Benchmark
## Student Information: 
**Name**:Pedro Hernandez Carranza 

**Student ID**: 008806974

**Repository Link**:

## Reflection
- What types of issues did you run into and how did you resolve them? 
  - I had the most trouble with the linked list variations due to poor pointer management. I ended up using a white board and carefully tracing out different cases to find where I had made errors. I also had trouble with sorting the vector. I tried a few ways and then looked at a few implementations on stack overflow and chatGPT but I did not understand them fully and could not get them to work properly. Ultimately I used the std::sort method which I'm sure is not the fastest approach but it gets the job done.


- Collaboration & Sources:
  - I used online resources like stack overflow and learned about some useful std methods like shuffle and sort. I mainly relied on my past assignments from instructor David Harden’s CS50C at the SRJC. It was interesting to see how complicated I made things that really did not need to be.


- Implementation Details:
  - For the sorting of the vector I used the std method sort after pushing the element on. This is most definitely not the best method but when I tried other ways the program would stall or crash. I clearly need more practice with vectors and using reference pointers. The sorted vectors look up using a binary search. The removal function also uses this.
  - For the unsorted linked list I simply add new nodes to the end. The lookup operation performs a leaner search. Removal does a leaner search and if the key is found then its adjacent nodes are connected and the key is deleted
  - For the sorted linked list I perform a linear search to determine where to add the new node. Search and removal still work in the same way
  - The main function was modified to include statistics about the average removal time. It mimics the structure of the average lookup time. I'm not sure if this is the correct approach but it appears to work and the results are reasonable


- Testing & Status:
  - My testing process involved using a lot of cout statements that stated what was happening and then checking if it actually took place. I did not create any testing functions or classes. I just tested as I went which was not the most systematic approach and is an area I can improve upon. I believe that all my functions work as intended but are definitely not the most efficient.

## Structure

- `src/`: Contains `Dictionary` interface and `UnsortedVectorDict` implementation.
- `.github/workflows/test.yml`: GitHub Actions CI setup.

## How It Works

1. UnsortedVectorDict.cpp is complete and the main function contains the necessary code to test it. 
2. The output provides the average run-time for the **insert** and **lookup** function. However, only the average run-time values for the unsorted vector variation is meaningful as the other variations have not been implemented yet.    
3. GitHub Actions runs 

## Run Locally

```bash
mkdir build && cd build
cmake ..
make
ctest --output-on-failure
```
